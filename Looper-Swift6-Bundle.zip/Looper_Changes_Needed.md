# Looper — Changes Needed

Working list only. No praise, no background — just what to fix. (Full evidence/reasoning for the audit items is in the published audit report, if you want to double-check anything.)

## Security

- [ ] **Ship a release from current `main`.** `v1.1.0` is still GitHub's "Latest," and it predates the local-file-only hardening (`AppDelegate.swift`, `AssetCache.swift`, `FileDropView`) and the project's only test. No new code needed for this one — just cut `v1.1.1` following the existing process in `BUILD_AND_RELEASE.md`.

## UI / Controls

- [ ] **Scrub bar is too transparent to see.** `VideoScrubBar.draw(_:)` in `VideoPlayer.swift` — the track is drawn at `NSColor.white.withAlphaComponent(0.35)`, which washes out over bright/light video.
- [ ] **Volume slider has the identical problem**, same file (`VolumeSlider.draw(_:)`) — same `0.35`-alpha white track. You didn't flag this one, but it's the same root cause, worth fixing in the same pass.
- [ ] **F7 / F8 / F9 and the volume keys don't do anything right now** — confirmed nothing in the code handles them today. Needed behavior: hold F7 = scrub backward at a steady pace, hold F9 = scrub forward, release = stop; F8 = play/pause; volume keys = adjust Looper's own volume. These arrive as macOS "media key" events, not ordinary keypresses, so this isn't just another case in the existing `handleKey` switch — it needs its own event path (system-defined `NSEvent`s, or `MPRemoteCommandCenter`, which is the more modern route and also gets you proper hold/repeat semantics for free). The existing scroll-wheel scrub code (`scheduleScrollSeek` / `flushScrollSeek`) is a good pattern to reuse for the "hold to scrub, release to stop" pacing.

## Performance / Reliability

- [ ] Cancel the background `Task.detached` asset loads in `AssetCache` when their window closes mid-load. Low impact today (calls are `[weak self]`-guarded), but real.
- [ ] Cap `WindowFrameStore`'s per-file `UserDefaults` entries — right now it grows forever, one key per file ever opened. `AssetCache.storeNativeSize` already has the right pattern (400-entry cap, trim to 300) — reuse it.
- [ ] Cancel `scrollEndWork` inside `tearDownPlayback()` — the other three scroll/HUD work items get cancelled there; this one doesn't.

## App Behavior

- [ ] **Add Cmd+Q / a menu bar.** No Dock icon, no menu bar, no Cmd+Q anywhere in the code — right now the only way to stop it is Activity Monitor or `pkill`. Worth treating as more than polish: Apple's WWDC 2026 AppKit session ("Modernize your AppKit app") is explicit that people should be able to quit an app at any time and that apps shouldn't block termination unnecessarily.
  - Cool-feature options for the menu/status item, instead of a bare Quit item: a standard **Window menu** listing every open loop (idiomatic for a multi-window app), or a **Recent Files** quick-reopen list — you're already tracking window frames and cached metadata per path, so an instant-reopen list of the last few files is just surfacing state that already exists.
  - macOS 27's Liquid Glass refinements (`NSGlassEffectView`) would make either of these look current for free if it's built with them instead of a plain menu-bar icon.

## CI / Release Process

- [ ] Remove the `|| echo "Smoke tests validated"` fallback in `.github/workflows/ci.yml` — as written, the Test step can't fail no matter what the tests do.

## Docs

- [ ] `docs/ARCHITECTURE.md` step 3 says the build "Installs `/Applications/Looper.app`" — it doesn't (contradicts both the actual script and `BUILD_AND_RELEASE.md`). Fix the step.
- [ ] `docs/ARCHITECTURE.md`'s supported-formats list is missing `m4v` (`README.md` already lists it correctly).

## Tests

- [ ] The only test in the project is `XCTAssertTrue(true)`. Worth real coverage on `LocalVideoURL.isPlayableFile`, `AssetCache`'s caching/key behavior, `WindowFrameStore` round-tripping, and `formatTime`/`formatRate` — all pure, cheap to test, currently untested.

## Worth Considering — macOS 27 / Newest Swift

Not "needed" fixes — opportunities, now that both shipped this week (macOS 27 Golden Gate: Sept 14; Swift 6.4: Sept 15).

- **Liquid Glass / `NSGlassEffectView`** — the AppKit class for the Liquid Glass material, which macOS 27 continues to refine (system-managed contrast/legibility, a new "bounce on click" response for controls). Directly useful for two items above: a more idiomatic fix for the scrub bar/volume slider transparency than hand-tuning alpha values, and what would make a new menu bar/status item look current rather than dated.
- **macOS 27 is Apple Silicon-only** — the first macOS version to drop Intel entirely. Looper's already arm64-only, so nothing to change here, just confirmation you're already positioned where the platform's going.
- [x] **Switch to Swift 6 language mode.** Done — `looper-swift6-migration.patch` bumps `SWIFT_VERSION` to `6.0` on both targets and makes `AssetCache.swift` compile under complete concurrency checking (`nonisolated(unsafe)` on the five `NSCache`-backed static caches, `@Sendable` on every completion-closure parameter that crosses into `Task.detached`). Apply and build in Xcode to confirm — I have no macOS/Swift toolchain here to compile-check it myself. If Xcode flags the `[weak self]` completion closures in `VideoPlayer.swift` (lines 639–672), it means `VideoPlayerWindowController` isn't being treated as `@MainActor`-isolated by the SDK you're building against; the fix is adding `@MainActor` to the class declaration.
- **Swift 6.4's Approachable Concurrency** (the `@concurrent` attribute and default-main-actor-isolation model, building on 6.2) — still a separate, optional step from the language-mode switch above. `AssetCache` still hand-rolls `Task.detached` + `MainActor.run` for every async load; adopting default-actor-isolation would let most of that go away, but it's a module-wide setting and a real rewrite of the loading functions, not a flag flip. Worth doing as its own follow-up, not bundled into this one.
- Checked for macOS 27 AVFoundation/`AVPlayer` playback-specific changes — didn't find anything relevant. This cycle's AVFoundation additions are camera/capture-side (autofocus tracking, lens control, broadcast metadata), not playback, so nothing new needed there.
